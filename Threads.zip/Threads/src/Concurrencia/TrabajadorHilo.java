package Concurrencia;

import java.util.Random;

public class TrabajadorHilo extends Thread {

	private String nombre;
	private Random rnd;
	
	// En esta clase sí hay dos hilos que 
	// compiten por ver quién termina de trabajar antes
	public static void main(String[] args) {
		
		// Crear instancias de Thread y pasarles una instancia de TrabajadorHilo
		Thread hilo1 = new Thread(new TrabajadorHilo("Pepe"));
		Thread hilo2 = new Thread(new TrabajadorHilo("José"));
		
		// Llamar al método start() en los objetos de tipo Thread
		hilo1.start();
		hilo2.start();
	}
	
	public TrabajadorHilo(String nombre)
	{
		this.nombre = nombre;
		this.rnd = new Random();
	}
	
	@Override
	public void run()
	{
		try {
			for (int i = 1; i <= 6; i++)
			{
				// Se empieza informando del paso que se va a realizar
				System.out.println(nombre + ": 'Estoy en el paso " + i + "'");
				// Se obliga a esperar un número de milisengundos aleatorio de 0 a 3000
				// Con este tiempo se estaría recreando lo que el trabajador tarda en completar el paso
				sleep(rnd.nextLong(3001));
			}
			// Cuando se salga del bucle ya habrá terminado el sexto paso e informará de que ha terminado de trabajar
			System.out.println("\n" + "**" + nombre + ": 'he terminado de trabajar'**" + "\n");
		} catch (InterruptedException e) {
			System.out.println("**ERROR**");
		}
	}
}
