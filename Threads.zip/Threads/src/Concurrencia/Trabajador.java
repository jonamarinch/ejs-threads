package Concurrencia;

public class Trabajador {
	
	private String nombre;
	
	// Se trata de la clase sin concurrencia ni hilos que sirve para 
	// contrastar con la clase que sí los tiene
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Trabajador tr1 = new Trabajador("Juan");
		Trabajador tr2 = new Trabajador("Santiago");
		tr1.realizarTarea();
		tr2.realizarTarea();
	}
	
	public Trabajador()
	{
		this.nombre = "";
	}
	
	public Trabajador(String nombre)
	{
		this.nombre = nombre;
	}
	
	private void realizarTarea()
	{
		for (int i = 1; i <= 6; i++)
		{
			System.out.println("Estoy en el paso " + i);
		}
		
		System.out.println(nombre + ": 'he terminado de trabajar'");
	}
}
