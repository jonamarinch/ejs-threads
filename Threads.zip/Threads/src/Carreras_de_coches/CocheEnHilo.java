package Carreras_de_coches;

import java.util.Random;

public class CocheEnHilo extends Thread {
	
	private String nombre;
	private int distanciaRecorrida;
	private Random rnd;
	
	public static void main(String[] args)
	{
		
		// Crear instancias de Thread y pasarles una instancia de CocheEnHilo
		Thread hilo1 =  new Thread(new CocheEnHilo("1"));
		Thread hilo2 = new Thread(new CocheEnHilo("2"));
		//
		hilo1.start();
		hilo2.start();
	}
	
	public CocheEnHilo(String nombre)
	{
		this.nombre = nombre;
		this.distanciaRecorrida = 0;
		this.rnd = new Random();
	}
	
	public int getDistanciaRecorrida()
	{
		return this.distanciaRecorrida;
	}
	
	public void acumularDistancia()
	{
		int distanciaHasta400;
		for (distanciaHasta400=0; distanciaHasta400 < 400; )
		{
			// La distancia se irá incrementando entre 50 y 150 hasta que llegue o supere los 400
			distanciaHasta400 += (rnd.nextInt(101)+50);
		}
		// Una vez llegue o supere los 400 la distancia recorrida se incrementará
		this.distanciaRecorrida += distanciaHasta400;
	}
	
	public long tiempoDescanso()
	{
		// El tiempo de descanso será de entre 1000 y 1500 milisegundos
		return (rnd.nextLong(501)+1000);
	}
	
	@Override
	public void run()
	{
		// En esta variable guardaremos el tiempo de descanso para poder imprimirlo por consola
		long tiempoDescanso;
		// Cuando la distancia llegue o supere las 1000 udes, se saldá del bucle y esto se comunicará por consola
		while(this.distanciaRecorrida < 1000)
		{
			// Lo primero en el bucle es acumular la distancia de entre 400 a 550 udes
			acumularDistancia();
			// Luego se obtiene un long random de milisegundos y lo guardamos en nuestra variable
			tiempoDescanso = tiempoDescanso();
			try {
				// Y usamos esta cantidad para el método sleep
				sleep(tiempoDescanso);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// Al final de cada vuelta al bucle se comunicará el tiempo de descanso y la distancia acumulada hasta ese momento
			System.out.println("***" + "\n" + "Coche " + this.nombre + "\n" + tiempoDescanso + " milisegundos" + " de descanso" + "\n" + this.distanciaRecorrida + " udes de distancia" + "\n" + "***");
		}
		// Cuando un coche sale del bucle por haber alcanzado las 1000 udes de distancia, se comunica su llegada a la meta
		System.out.println("**************************************");
		System.out.println("El coche " + this.nombre + " ha llegado a la línea de meta");
		System.out.println("**************************************");
	}
}
