package Sincronización;

public class ImpresoraNumeros {
	
	private int valorNum;
	
	public static void main (String[] args)
	{
		// Un único objeto Impresora
		ImpresoraNumeros impraaNum = new ImpresoraNumeros();
		
		// Crear una instancia de Thread y pasarle la instancia de ImpresoraNumeros
		Thread thread1 =  new Thread(new ImpresionNumeros(impraaNum, true));
		Thread thread2 = new Thread(new ImpresionNumeros(impraaNum, false));
		
		// Llamar al método start() en el objeto de tipo Thread
		thread1.start();
		thread2.start();
	}
	
	public ImpresoraNumeros()
	{
		this.valorNum = -1;
	}
	
	public synchronized void imprimirNumero(boolean logicaHilo) throws InterruptedException
	{	
		// Iniciamos el valor a imprimir a 1
		this.valorNum = 1;
		// El valor se imprimira hasta que supere el 10
		while (this.valorNum<=10)
		{
			// Un thread sólo imprimirá los pares, y otro los impares
			if ((valorNum%2==0 && logicaHilo) || (valorNum%2!=0 && !logicaHilo))
			{
				// Impresión
				System.out.println(logicaHilo + ">>" + "\n" + this.valorNum);
				// notify() para que el otro thread no se quede atrapado en el wait
				
				// incremento
				this.valorNum++;
				notify();	
			}
			else 
			{
				wait();
			}	
		}
	}
}
