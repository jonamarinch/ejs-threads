package Sincronización;

public class ImpresionNumeros implements Runnable{
	
	private ImpresoraNumeros impraNum;
	private boolean logico;
	
	// El constructor parametrizado recibirá la impresora (será la misma en ambos casos)
	// y un buleano (será true o false según imprima números pares o impares)
	public ImpresionNumeros(ImpresoraNumeros impraNum, boolean logico)
	{
		this.impraNum = impraNum;
		this.logico = logico;
	}

	@Override
	public void run()
	{
		try {
			// Al usar la impresora se informará del dato de tipo lógico para que se pueda controlar allí
			this.impraNum.imprimirNumero(this.logico);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
